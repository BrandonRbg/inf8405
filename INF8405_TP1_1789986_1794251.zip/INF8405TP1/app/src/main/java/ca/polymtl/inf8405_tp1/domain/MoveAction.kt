package ca.polymtl.inf8405_tp1.domain

data class MoveAction(
    val movement: Position,
    val pieceId: Int
)