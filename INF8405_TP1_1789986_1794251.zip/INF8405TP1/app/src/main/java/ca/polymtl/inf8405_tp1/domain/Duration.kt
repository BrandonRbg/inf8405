package ca.polymtl.inf8405_tp1.domain

fun Int.seconds() = this * 1000L